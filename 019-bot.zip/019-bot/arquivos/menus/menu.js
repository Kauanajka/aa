const menu = (prefix, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender) => {
return `
CLIENTE: ${pushname}

VENDEDOR: ${nomeBot}
`
}
exports.menu = menu

const menuadm = (prefix, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender) => {
return `
╔═══════════╗
┣⋆⃟ۣۜ᭪➣${prefix}antilink 1
┣⋆⃟ۣۜ᭪➣${prefix}antilink 0
┣⋆⃟ۣۜ᭪➣${prefix}resetarlink
┣⋆⃟ۣۜ᭪➣${prefix}botsai
┣⋆⃟ۣۜ᭪➣${prefix}hidetag
┣⋆⃟ۣۜ᭪➣${prefix}ban @
┣⋆⃟ۣۜ᭪➣${prefix}mudardk
┣⋆⃟ۣۜ᭪➣${prefix}mudarnm
┣⋆⃟ۣۜ᭪➣${prefix}grupo a
┣⋆⃟ۣۜ᭪➣${prefix}grupo f
┣⋆⃟ۣۜ᭪➣${prefix}promover @
┣⋆⃟ۣۜ᭪➣${prefix}rebaixar @
╚═══════════╝
`
}
exports.menuadm = menuadm

const menubrincadeira = (prefix, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender) => {
return `
╔═══════════╗
┣⋆⃟ۣۜ᭪➣${prefix}cassino 
`
}
exports.menubrincadeira = menubrincadeira

const menualeatorio = (prefix, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender) => {
return ` 
     -menu-
╔═══════════╗
┣⋆⃟ۣۜ᭪➣${prefix}menuprem
┣⋆⃟ۣۜ᭪➣${prefix}menuadm
┣⋆⃟ۣۜ᭪➣${prefix}menu2
┣⋆⃟ۣۜ᭪➣${prefix}video
┣⋆⃟ۣۜ᭪➣${prefix}audio
┣⋆⃟ۣۜ᭪➣${prefix}perfil
┣⋆⃟ۣۜ᭪➣${prefix}listadm
╚═══════════╝
    *♨️⭐️♨️*
╔═══════════╗
┣⋆⃟ۣۜ᭪➣${prefix}novocmd
┣⋆⃟ۣۜ᭪➣${prefix}bug
╚═══════════╝
    *sticker*
╔═══════════╗
┣⋆⃟ۣۜ᭪➣${prefix}s
┣⋆⃟ۣۜ᭪➣${prefix}toimg
╚═══════════╝
*Dono*
╔═══════════╗
┣⋆⃟ۣۜ᭪➣${prefix}tmgp
╚═══════════╝

`
}
exports.menualeatorio = menualeatorio

